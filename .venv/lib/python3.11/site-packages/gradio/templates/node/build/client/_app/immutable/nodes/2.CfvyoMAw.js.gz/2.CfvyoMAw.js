import { N, _ } from "../chunks/2.CWvEmQ0K.js";
export {
  N as component,
  _ as universal
};
